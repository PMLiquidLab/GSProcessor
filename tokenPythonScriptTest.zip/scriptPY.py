import os
import numpy as np
import xmltodict
import json
from sklearn.decomposition import PCA
from kneed import KneeLocator
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import pandas as pd
import sys
from datetime import datetime
import base64
from io import BytesIO
from ds_utils.unsupervised import plot_cluster_cardinality, plot_cluster_magnitude, plot_magnitude_vs_cardinality
from scipy.spatial.distance import euclidean
import matplotlib.pyplot as plt

paramfileName = sys.argv[1]

def main(paramfileName):
    dirname = os.path.dirname(paramfileName)
    cwd = os.getcwd()
    with open(paramfileName, 'r') as f:
        lst_parametri = json.load(f)
    outputFolder = lst_parametri['header']['executionFolderFullName'][0]
    run_id =  lst_parametri['header']['run.id'][0]
    tokenInstanceUID = lst_parametri['header']['tokenInstanceUID'][0]
    fileName4output = outputFolder+"/output.txt"
    fileName4descriptor = outputFolder+"/description.xml"
    fileName4outputReport = outputFolder+"/output_report.html"
    fileName4outputData = outputFolder+"/output_data.csv"
    token_waiting_filename = lst_parametri["header"]["token.waiting.filename"][0]
    columnDescriptorFileName = ''

    for el in lst_parametri['payload']['lst.other']: 
        if lst_parametri['payload']['lst.other'][el]['alias'][0] == 'columnDescriptor':
            columnDescriptorFileName = lst_parametri['payload']['lst.other'][el]['fileName'][0]
    os.chdir(dirname)

    #if columnDescriptorFileName != '':
    #    col_description = colDescriptionReader(columnDescriptorFileName)
    #else: 
    #    col_description = pd.DataFrame(columns = ['alias', 'colName', 'colDataType', 'dataSourceAlias', 'dataSourceFileName', 'creationDateTime'] ) 

    
    #load the dataset
    DB = pd.read_csv(lst_parametri['payload']['lst.dataSource'][run_id]['dataSourceFileName'][0])
    
    os.chdir(cwd)
    #----------------------------------------------
    # Select columns for clustering
    #---------------------------------------------
    
    #discard_columns = col_description[col_description['colDataType'].isin(['key', 'target'])]['colName'].to_list()
    #dummy_columns = col_description[col_description['colDataType'].isin(['cathegorical'])]['colName'].to_list()
    # fai il dummy in caso
    
    #cols = [item for item in list(DB) if item not in discard_columns]
    cols = ["F_stat.mean", "F_stat.median","F_stat.10thpercentile","F_stat.90thpercentile"]
    DB_clustering = DB[cols]
    #--------------------------------------------------------
    # Generate clustering report
    #--------------------------------------------------------
    
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(DB_clustering)
    kmeans_kwargs = {
    "init": "random",
    "n_init": 10,
    "max_iter": 300,
    "random_state": 42,
    }

    # A list holds the SSE values for each k
    sse = []
    for k in range(1, 11):
        kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
        kmeans.fit(scaled_features)
        sse.append(kmeans.inertia_)
    
    kl = KneeLocator(
    range(1, 11), sse, curve="convex", direction="decreasing"
    )
    # Final decision
    km = KMeans(n_clusters=kl.elbow, 
                max_iter=300, 
                tol=1e-04, 
                init='k-means++', 
                n_init=10, 
                random_state=42, 
                algorithm='auto')

    km_fit = km.fit(scaled_features)
    
    cluster_colors = ['#b4d2b1', '#568f8b', '#1d4a60', '#cd7e59', '#ddb247', '#d15252']

    fig1, (ax1, ax2, ax3) = plt.subplots(1,3,figsize=(17,4), dpi=80)

    plot_cluster_cardinality(km_fit.labels_,
                             ax=ax1,
                             title="Cardinality",
                             color=cluster_colors
                            )
    plot_cluster_magnitude(scaled_features,
                           km_fit.labels_,
                           km_fit.cluster_centers_,
                           euclidean,
                           ax=ax2,
                           title="Magnitude",
                           color=cluster_colors
                          )
    plot_magnitude_vs_cardinality(scaled_features,
                                  km_fit.labels_,
                                  km_fit.cluster_centers_,
                                  euclidean,
                                  color=cluster_colors[0:km_fit.n_clusters],
                                  ax=ax3, 
                                  title="Magnitude vs. Cardinality")

    fig1.autofmt_xdate(rotation=0)
    plt.tight_layout()
    
    fig2, ax1 = plt.subplots(1,1,figsize=(17,4), dpi=80)

    # PCA
    pca_scaled_std = PCA(n_components=2,random_state=42)
    X_std_pca = pca_scaled_std.fit_transform(scaled_features)

    for l, c, m in zip(range(0, 4), cluster_colors[0:km_fit.n_clusters], ('^', 's', 'o','x')):
        ax1.scatter(X_std_pca[np.where(km_fit.labels_==l), 0],
                    X_std_pca[np.where(km_fit.labels_==l), 1],
                    color=c,
                    label='cluster %s' % l,
                    alpha=0.9,
                    marker=m
                    )


    ax1.set_title("PCA Visualization")
    #ax2.set_title("PACMAP Visualization")

    labels = np.unique(km_fit.labels_)
    labels = ["cluster "+str(l) for l in labels]
    fig2.legend(labels, loc='lower center',ncol=len(labels), bbox_transform=(1,0),borderaxespad=-0.5)
    plt.tight_layout()
    
    features = cols
    DB['cluster'] = km_fit.labels_
    DB.to_csv(fileName4outputData)
    ncols = 4
    nrows = len(features) // ncols + (len(features) % ncols > 0)
    fig3 = plt.figure(figsize=(17,45), dpi=80)

    for n, feature in enumerate(features):
        ax = plt.subplot(nrows, ncols, n + 1)
        box = DB[[feature, 'cluster']].boxplot(by='cluster',ax=ax,return_type='both',patch_artist = True)

        for row_key, (ax,row) in box.iteritems():
            ax.set_xlabel('cluster')
            ax.set_title(feature,fontweight="bold")
            for i,box in enumerate(row['boxes']):
                box.set_facecolor(cluster_colors[i])

    fig3.suptitle('Feature distributions per cluster', fontsize=18, y=1)   
    plt.tight_layout()
    
    
    html0 = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=utf-8">    <meta name="viewport" content="width=device-width"><title>vertical margin</title></head><body>'

    tmpfile1 = BytesIO()
    fig1.savefig(tmpfile1, format='png')
    encoded1 = base64.b64encode(tmpfile1.getvalue()).decode('utf-8')
    html1 = '<div>'+'<img src=\'data:image/png;base64,{}\'>'.format(encoded1)+'</div>'

    tmpfile2 = BytesIO()
    fig2.savefig(tmpfile2, format='png')
    encoded2 = base64.b64encode(tmpfile2.getvalue()).decode('utf-8')
    html2 = '<div>'+'<img src=\'data:image/png;base64,{}\'>'.format(encoded2)+'</div>'

    tmpfile3 = BytesIO()
    fig3.savefig(tmpfile3, format='png')
    encoded3 = base64.b64encode(tmpfile3.getvalue()).decode('utf-8')
    html3 = '<div>'+'<img src=\'data:image/png;base64,{}\'>'.format(encoded3)+'</div> </body></html>'

    with open(fileName4outputReport,'w') as f:
        f.write(html0)
        f.write(html1)
        f.write(html2)
        f.write(html3)
    
    # -------------------------------------------------------
    # Generate the output XML
    # -------------------------------------------------------
    
    xml_output_string = """<xml>
                            <XMLheader>
                              <tokenInstanceUID>##tokenInstanceUID##</tokenInstanceUID>
                              <runUID>##runUID##</runUID>
                              <creationDateTime>##creationDateTime##</creationDateTime>
                            </XMLheader>
                            <XMLobj objType='other'>
                              <resourceFileType>##resourceFileType1##</resourceFileType>
                              <resourceFileName>##resourceFileName1##</resourceFileName>
                            </XMLobj>
                            <XMLobj objType='other'>
                              <resourceFileType>##resourceFileType2##</resourceFileType>
                              <resourceFileName>##resourceFileName2##</resourceFileName>
                            </XMLobj>
                          </xml>"""
    xml_output_string = xml_output_string.replace("##tokenInstanceUID##",tokenInstanceUID)
    xml_output_string = xml_output_string.replace("##runUID##",run_id)
    xml_output_string = xml_output_string.replace("##creationDateTime##",datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
    xml_output_string = xml_output_string.replace("##resourceFileName1##","output_report.html")
    xml_output_string = xml_output_string.replace("##resourceFileType1##","HTML report")
    xml_output_string = xml_output_string.replace("##resourceFileName2##","output_data.csv")
    xml_output_string = xml_output_string.replace("##resourceFileType2##","outputData")
    
    text_file = open(fileName4descriptor, "w")
    n = text_file.write(xml_output_string)
    text_file.close()
    print("finito")

    text_file = open(token_waiting_filename, "w")
    n = text_file.write("fine")
    text_file.close()


def colDescriptionReader(xmlFileName):
    with open(xmlFileName, 'r', encoding='utf-8') as file:
        my_xml = file.read()
    my_dict = xmltodict.parse(my_xml)
    col_description = pd.DataFrame(my_dict['xml']['columnSpec'], columns = ['alias', 'colName', 'colDataType'])
    source_description = pd.DataFrame(my_dict['xml']['XMLheader'], columns = ['dataSourceAlias', 'dataSourceFileName' ,'creationDateTime' ], index =[0])
    col_description = col_description.merge(source_description, how = 'cross')
    return col_description

        
if __name__ == "__main__":
    main(paramfileName)
